# R-Coin: phone + GitHub Codespaces (English command labels, Hindi instructions)

Current GitHub repository initially contains `README.md` and `R-Coin_checkpoint_17.zip`. The ZIP is **not** the extracted app. Use your own **private** repository and do not share secrets/screenshots of OTPs or `.env`.

## Step 1: Find the terminal
Open the Codespace. If the Explorer appears empty, wait for the connection, tap refresh and expand the `R-coin` folder. In the browser VS Code menu, choose **Terminal → New Terminal** (on a narrow phone screen use the `☰` menu). Type:

```bash
pwd
ls -la
```

Confirm `R-Coin_checkpoint_17.zip` appears in the output. If not, refresh the Explorer / Codespace and check you are in the repository directory before continuing. Do not paste secrets into chat.

## Step 2: Extract and import the existing ZIP
Only if `R-Coin_checkpoint_17.zip` is present:

```bash
unzip -t R-Coin_checkpoint_17.zip
unzip -q R-Coin_checkpoint_17.zip
cp -a rcoin16/. .
ls -la apps/api apps/web scripts docs
node scripts/check-foundation.mjs
node --experimental-strip-types scripts/check-totp.mjs
node scripts/check-totp-claims.mjs
node --experimental-strip-types scripts/check-totp-vectors.mjs
```

Expected: four `PASS` results. These do not prove that the app runs. If `unzip -t` fails, stop. Do not run later commands on a failed extraction.

## Step 3: Save source files to GitHub
In Codespaces Source Control, review the changed files before committing. Do **not** add `.env`, `node_modules`, passwords, OTPs or actual database data. `.gitignore` excludes `.env` files. When source is committed and pushed, the repository should show `apps/`, `docs/`, `scripts/` (and any checkpoint's `.github/` directory), not only the ZIP. To remove the old archive from the repository after confirming source import:

```bash
git rm --cached R-Coin_checkpoint_17.zip
```

Commit/push the change. This removes it from future Git history snapshots, **not** from older history; if the archive ever contained secrets, rotating them and cleaning history requires a separate review.

## Step 4: Using the newer Checkpoint 18 archive
The Checkpoint 18 ZIP supplied separately contains the same source plus a one-command offline gate, optional Codespaces config and GitHub Actions workflow. Import it in place of Checkpoint 17 when ready; it also extracts into `rcoin16/`. Once imported and committed, run:

```bash
node scripts/check-offline.mjs
```

Check the GitHub **Actions** tab after pushing. The workflow runs only after `.github/workflows/offline-foundation.yml` exists in the repository as an extracted file. Its green result does not mean the API, DB or security is ready.

## Next milestone, not yet verified
Use working package access for npm/Prisma/builds, then an isolated PostgreSQL database and test SMTP for end-to-end tests. Never use real money or personal documents with this closed-test app. No public transfer endpoint exists.
