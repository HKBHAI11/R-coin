# Checkpoint 19 — Runtime prerequisites preflight

Continues Checkpoint 18. Closed-test nonredeemable credits only. No API, UI, schema or ledger behavior changed.

## Completed
- Added read-only `scripts/check-runtime-prereqs.mjs` showing Node version, dependency directories, generated Prisma client and API `.env` presence without printing secrets.
- Checked script syntax and execution and reran four offline foundation checks.
- Presence checks are not dependency, service, functionality or security validation.

## Pending
- Codespaces: install API/web dependencies, validate/generate Prisma, build and run unit tests.
- Isolated PostgreSQL and test SMTP; review migration before applying; registration/login/wallet E2E.
- All release blockers in `docs/PENDING_FEATURES.md`; no public transfers or real-money use.

From repository root run `node scripts/check-offline.mjs` and `node scripts/check-runtime-prereqs.mjs`. Never commit `.env` or credentials.
