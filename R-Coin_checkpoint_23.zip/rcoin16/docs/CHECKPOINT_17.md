# Checkpoint 17 — Independent technical audit and session helper consolidation

Based on Checkpoint 16. No feature expansion. Changes from audit:

- Consolidated session cookie parsing and token hashing in `auth.ts` to reuse `sessionToken` / `tokenHash` from `session.ts`.
- Aligned `/auth/me` expiry check to `expiresAt <= new Date()` (consistent with `requireSession`).
- Removed local `cookie()` helper and unused `createHash` import in `auth.ts`.
- Extended `scripts/check-foundation.mjs` source guards for the shared helpers and consistent expiry check.
- No behavioral change to registration, TOTP, MPIN, wallet overview, or ledger.

## Verification performed in this environment (2026-10-26)

### PASS (dependency-free / static)
```
node scripts/check-foundation.mjs
# → PASS: static foundation checks
# → PASS: OTP/MPIN regex, shared session helpers and MPIN CAS source guards
# → PASS: shared Prisma client centralization guard

node --experimental-strip-types scripts/check-totp.mjs
# → PASS: dependency-free TOTP runtime round-trip

node scripts/check-totp-claims.mjs
# → PASS: TOTP setup/confirmation conditional-write source guards

node --experimental-strip-types scripts/check-totp-vectors.mjs
# → PASS: six RFC 6238 SHA-1 vectors, window boundaries, invalid input
```

### BLOCKED (environment limitations)
- Full `npm install` for `apps/api` and `apps/web` (repeated timeouts / incomplete resolution against the sandbox registry; partial `node_modules` observed).
- `npx prisma validate` / `prisma generate` / `prisma migrate` (no usable Prisma CLI binary after install attempts; no PostgreSQL server present).
- TypeScript `tsc` builds for API and web.
- Unit tests via `tsx --test src/*.test.ts` (tsx / dependencies unavailable).
- Live registration, email OTP delivery, TOTP setup/confirm, login, MPIN setup/verify, wallet overview (requires PostgreSQL + SMTP + running server).
- Concurrency / lockout stress under a real database.
- Browser / CORS / cookie end-to-end.

### NOT TESTED
- Rate-limit effectiveness under concurrent load (in-memory only).
- CSRF beyond Origin header checks.
- Recovery codes, trusted-device re-login, TOTP setup expiry / durable anti-replay.
- Public transfer path (intentionally not exposed).
- KYC, admin, support ticket handling beyond submission.
- Production security review or penetration testing.

## Security / concurrency notes (code review only)
- Conditional `updateMany` claims remain on TOTP setup/confirm and MPIN lockout (CAS loop).
- Email verification uses Serializable isolation + claim on `emailVerifiedAt:null` + `status:EMAIL_PENDING`.
- Ledger transfer helper (unexposed) uses Serializable + conditional debit `balanceMinor:{gte:...}`.
- In-memory rate limits and Origin-only CSRF are explicitly not production-grade.
- TOTP window is ±1 period; no additional anti-replay store.
- Session cookies: httpOnly, sameSite=strict, path=/, secure in production.

## Explicit non-claims
This checkpoint does **not** assert production readiness, complete dependency installation, successful migrations, or end-to-end auth/wallet flows. R-Coin remains closed-test nonredeemable credits only. Do not deploy.