# Checkpoint 23 — Admin review backend source
- User role MEMBER/ADMIN, defaults MEMBER. No public promotion endpoint; provisioning requires separately reviewed operator procedure.
- Session reads current DB role. Admin-only pending queue and Origin-checked review route.
- Serializable transaction atomically claims PENDING request; APPROVE increments wallet and posts balanced issuance journal with unique request idempotency key; REJECT adds no credits; duplicate review conflicts.
- Closed-test nonredeemable credits only. No cash value, deposits or redemption.
- PENDING: migration review, database and build testing, admin provisioning, integration/concurrency/security tests, UI and QR transfers. Do not deploy this unverified source.
