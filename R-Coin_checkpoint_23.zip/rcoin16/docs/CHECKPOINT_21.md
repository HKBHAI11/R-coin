# Checkpoint 21 — User credit requests (API foundation)

Closed-test nonredeemable credits, no cash value. Added authenticated `POST /credit-requests` and `GET /credit-requests/mine`. The server derives user identity from the session, validates a positive integer minor-unit amount (max 15 digits), limits each user to 3 pending requests (best-effort; concurrent race remains), and returns only the caller’s latest 30 requests. POST requires trusted Origin. No request directly changes wallet balance. No approval, payment collection, or admin privilege route has been added.

## Pending before production or even public testing
Review/apply Prisma migration on isolated PostgreSQL; install dependencies and run TypeScript build, integration tests, shared/distributed rate limiting and atomic pending-request limit. Design separately authorized admin reviewer role, fresh TOTP, audited idempotent issuance and balanced ledger transaction. Verify full user and admin workflows, secure hosting and anti-abuse controls. This is NOT security-certified.
